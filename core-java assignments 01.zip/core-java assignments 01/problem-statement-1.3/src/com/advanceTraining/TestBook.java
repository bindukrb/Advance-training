package com.advanceTraining;

import java.util.Scanner;

public class TestBook {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
	    int n= sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the Book name:");
        String bookname=sc.nextLine();
        
        System.out.println("Enter the price:");
        int price=sc.nextInt();
        sc.nextLine();
        
        
        Book obj=new Book();
        
        obj.setTitle(bookname);
        obj.setPrice(price);
        System.out.println("Book Details");
        System.out.println("Book Name :"+obj.getTitle());
        System.out.println("Book Price :"+obj.getPrice());
        showBooks(createBooks(n), n);
        

	}
	
	public static Book[] createBooks(int n) {
	    
	    
	    Book obj[]= new Book[n];

	    for(int i=0; i<n; i++){
	      obj[i]= new Book();
	      obj[i].setTitle("Title "+ i);
	      obj[i].setPrice(i*100);
	    }
	    
	    return obj;
	  }

	  public static void showBooks(Book obj[], int n) {
	    System.out.println("Book Title      Price");
	    for(int i=0; i<n; i++){
	      System.out.print(obj[i].getTitle());
	      System.out.print("      ");
	      System.out.println(obj[i].getPrice());
	    }
	  }

}
