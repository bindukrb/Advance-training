package com.advanceTraining;

public class Array {

	public static void main(String[] args) {
		
		 
        int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0}; 
        
     
        int sum = 0;  
        int max=arr[0];
       
       
        for (int i = 0; i < arr.length; i++) {  
           sum = sum + arr[i];  
        }  
        System.out.println("Sum of all the elements of an array: " + sum);  
        
        
        for(int i=0; i<arr.length;i++) {
      	  if(arr[i]>max)
      		  max=arr[i];
        }
        
        arr[16]=sum/arr.length;
        
        arr[17]=max;
        
      arr[15]=sum;
      
      
     

      for(int i=0;i<arr.length;i++) {
    	  System.out.print("," +arr[i]);
      }
	
	}

}
