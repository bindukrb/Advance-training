package com.advance_trainig;

import java.util.Scanner;

public class ListOfEvenNumbers {

	public static void main(String[] args) {
		
		int n ;
		
		Scanner scan=new Scanner(System.in);
		
		System.out.println("enter the number, upto even numbers to get..");
		n= scan.nextInt();

		System.out.print("Even Numbers from 1 to "+ n +" are:\n ");

		for (int i = 1; i <= n; i++) {


		   if (i % 2 == 0) {

		 System.out.print(i + " ");

		   }

		}
	}

}
