package com.advanceTraining;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		
		String str, rev = "";
	    Scanner sc = new Scanner(System.in);
	 
	    System.out.println("Enter a string:");
	    str = sc.nextLine();
	 
	    String upper =str.toUpperCase();
	    
	    System.out.println(upper);
	    int length = str.length();
	 
	    for ( int i = length - 1; i >= 0; i-- )
	       rev = rev + upper.charAt(i);
	 
	    if (upper.equals(rev))
	       System.out.println(upper+" is a palindrome and length of the "+upper+" is-->"+upper.length());
	      
	    else
	         System.out.println(upper+" is not a palindrome and length of the "+upper+" is-->"+upper.length());
	 

	}

}
