package com.advanceTraining;

import java.util.Scanner;

public class GetBookDetails {
	
	static Book book1=new Book();
	
	public static void main(String[] args) {
		
		
		 GetBookDetails obj=new GetBookDetails();
		obj.createBooks();
		obj.showBooks();
		
	}
	
	

	public  void createBooks() {
			
		Scanner scan = new Scanner(System.in);
		System.out.println("enter book name and price");
			book1.setTitle(scan.nextLine());
			book1.setPrice(scan.nextInt());
	
	}
	
	public void showBooks() {
		
		System.out.println("Book Name "+ book1.getTitle());
		
		System.out.println("Price "+ book1.getPrice());
	}

}
