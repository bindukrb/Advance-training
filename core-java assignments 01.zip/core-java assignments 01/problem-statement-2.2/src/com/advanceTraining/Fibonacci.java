package com.advanceTraining;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		
		int n1,n2,n3,i, count=14;  
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter the 1st number");
		n1=sc.nextInt();
		
		System.out.println("enter the 2nd number");
		n2=sc.nextInt();
			
		System.out.print(n1+" "+n2); 
		  
		for(i=0;i<count;i++)  {  
			 
			  n3=n1+n2;  
			  System.out.print(" "+n3);  
			  n1=n2;  
			  n2=n3;  
		
		 } 

	}

}
