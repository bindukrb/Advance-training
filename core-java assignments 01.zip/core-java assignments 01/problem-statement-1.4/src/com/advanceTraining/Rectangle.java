package com.advanceTraining;

import java.util.Scanner;

public class Rectangle {
	
	float length; 
    float width; 
    float area; 
    float parameter;
    
    public float getLength() {
		return length;
	}

	public void setLength(float length) {
		if(length>0.0 && length<20.0)
			this.length = length;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		if(width>0.0 && width<20.0)
			this.width = width;
	}

	
    public Rectangle()
    {
    	length = 1;
    	width= 1;
    }

    void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextFloat();
        System.out.print("Enter width of rectangle: ");
        width = in.nextFloat();
    }
    
    void  areaRectangle()
    {
    	if(length>0.0 && length<20.0)
    		area = length * width;
       
    }
 
     void  perimeterRectangle()
    {
    	if(length>0.0 && length<20.0)
    		parameter = 2*(length + width);
       
    }

    void display() {
    	if(length>0.0 && length<20.0)
        {
    		System.out.println("Area of Rectangle = " + area);
    		System.out.println("Parameter of Rectangle = " +parameter);}
       
        }
	
	

	public static void main(String[] args) {
		

		Rectangle obj1 = new Rectangle();
		
		System.out.println("enter length and breadth");
		
		Scanner scan=new Scanner(System.in);
		
       // obj1.input();
		obj1.setLength(scan.nextFloat());
		obj1.setWidth(scan.nextFloat());
        obj1.areaRectangle();
        obj1.perimeterRectangle();
        obj1.display();

	}

}
