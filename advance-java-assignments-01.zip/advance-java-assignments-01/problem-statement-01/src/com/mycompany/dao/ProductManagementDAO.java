package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.product;

public class ProductManagementDAO {

	
	public static int viewall(product pb) throws SQLException, ClassNotFoundException {
		String sql = " Select * from product";
		Connection con = DBUtil.dbConn();
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		int count = 0;
		while (rs.next()) {

			// pw.println(rs.getInt(1)+" "+rs.getString(2));
			System.out.println("\n Product Id: "+rs.getString(1) + "\n Product Name: " + rs.getString(2) + "\n Product Price: " + rs.getDouble(3));			count++;
		}
		return count;
	}

	
	public static int insert(product pb) throws ClassNotFoundException, SQLException {
		String sql = "insert into product values(?,?,?)";
		Connection con = DBUtil.dbConn();
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, pb.getProductID());
		ps.setString(2, pb.getProductName());
		ps.setInt(3, pb.getProduct_Price());
		return ps.executeUpdate();

	}
	
	public static int update(product pb) throws SQLException, ClassNotFoundException {
		String sql = " Update product set  ProductName =? , Product_Price = ?  where ProductID = ?";
		Connection con = DBUtil.dbConn();
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, pb.getProductName());
		ps.setInt(2, pb.getProduct_Price());
		ps.setInt(3, pb.getProductID());
		return ps.executeUpdate();
	}

	public static int delete(product pb) throws SQLException, ClassNotFoundException {
		String sql = "delete from product where ProductID =?";
		Connection con = DBUtil.dbConn();
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, pb.getProductID());
		return ps.executeUpdate();

	}
	
	public static int search(product pb) throws SQLException, ClassNotFoundException {
		String sql = " select * from product where ProductID =?";
		Connection con = DBUtil.dbConn();
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, pb.getProductID());
		ResultSet rs = ps.executeQuery();
		int count = 0;
		while (rs.next()) {

			System.out.println("\n Product Id: "+rs.getString(1) + "\n Product Name: " + rs.getString(2) + "\n Product Price: " + rs.getDouble(3));
			count++;
		}
		return count;

	}
	
}
